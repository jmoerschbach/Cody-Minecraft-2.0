b = peripheral.wrap("monitor_0")
while true do 
end
